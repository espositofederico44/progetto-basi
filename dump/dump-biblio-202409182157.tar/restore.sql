--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE biblio;
--
-- Name: biblio; Type: DATABASE; Schema: -; Owner: federico
--

CREATE DATABASE biblio WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United Kingdom.1252';


ALTER DATABASE biblio OWNER TO federico;

\connect biblio

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: stato_libro; Type: TYPE; Schema: public; Owner: federico
--

CREATE TYPE public.stato_libro AS ENUM (
    'disponibile',
    'inprestito'
);


ALTER TYPE public.stato_libro OWNER TO federico;

--
-- Name: tipo_lettore; Type: TYPE; Schema: public; Owner: federico
--

CREATE TYPE public.tipo_lettore AS ENUM (
    'base',
    'premium'
);


ALTER TYPE public.tipo_lettore OWNER TO federico;

--
-- Name: tipo_utenti; Type: TYPE; Schema: public; Owner: federico
--

CREATE TYPE public.tipo_utenti AS ENUM (
    'admin',
    'bibliotecario',
    'lettore'
);


ALTER TYPE public.tipo_utenti OWNER TO federico;

--
-- Name: add_author(character varying, character varying, text, date, date); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.add_author(IN p_nome character varying, IN p_cognome character varying, IN p_biografia text, IN p_data_nascita date, IN p_data_morte date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Inserisce un nuovo autore nella tabella 'autori' con nome, cognome, biografia, data di nascita e, opzionalmente, data di morte.
    -- La data di morte può essere NULL, in quanto l'autore potrebbe essere ancora in vita.
    INSERT INTO autori (nome, cognome, biografia, data_nascita, data_morte)
    VALUES (p_nome, p_cognome, p_biografia, p_data_nascita, p_data_morte);
END;
$$;


ALTER PROCEDURE public.add_author(IN p_nome character varying, IN p_cognome character varying, IN p_biografia text, IN p_data_nascita date, IN p_data_morte date) OWNER TO federico;

--
-- Name: add_book(character varying, character varying, text); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.add_book(IN _isbn character varying, IN _titolo character varying, IN _trama text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO libri (isbn, titolo, trama)
    VALUES (_isbn, _titolo, _trama);
END;
$$;


ALTER PROCEDURE public.add_book(IN _isbn character varying, IN _titolo character varying, IN _trama text) OWNER TO federico;

--
-- Name: add_book_to_branch(integer, character varying); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.add_book_to_branch(IN _sede_id integer, IN _isbn character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Inserimento del libro nella tabella 'catalogo'
    INSERT INTO catalogo (sede, isbn) 
    VALUES (_sede_id, _isbn);
END;
$$;


ALTER PROCEDURE public.add_book_to_branch(IN _sede_id integer, IN _isbn character varying) OWNER TO federico;

--
-- Name: add_branch(character varying, character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.add_branch(IN p_nome character varying, IN p_indirizzo character varying, IN p_cap character varying, IN p_comune_id integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_branch_id integer;
BEGIN
    -- Inserisce una nuova sede nella tabella 'sedi' e restituisce il suo ID
    INSERT INTO sedi (nome, indirizzo, cap, comune)
    VALUES (p_nome, p_indirizzo, p_cap, p_comune_id)
    RETURNING id INTO new_branch_id;
END;
$$;


ALTER PROCEDURE public.add_branch(IN p_nome character varying, IN p_indirizzo character varying, IN p_cap character varying, IN p_comune_id integer) OWNER TO federico;

--
-- Name: add_loan(character varying, integer, date, date); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.add_loan(IN _cf_lettore character varying, IN _id_catalogo integer, IN _data_inizio date, IN _data_fine date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Verifica se il libro è disponibile
    IF (SELECT is_book_available(_id_catalogo)) THEN
        -- Inserisce il prestito nella tabella 'prestiti'
        INSERT INTO prestiti (cf_lettore, id_catalogo, data_inizio, data_fine)
        VALUES (_cf_lettore, _id_catalogo, _data_inizio, _data_fine);
    ELSE
        -- Se il libro non è disponibile, solleva un'eccezione
        RAISE EXCEPTION 'Il libro non è disponibile per il prestito.';
    END IF;
END;
$$;


ALTER PROCEDURE public.add_loan(IN _cf_lettore character varying, IN _id_catalogo integer, IN _data_inizio date, IN _data_fine date) OWNER TO federico;

--
-- Name: aggiorna_viste_materializzate(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.aggiorna_viste_materializzate() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Aggiorna entrambe le viste materializzate
    REFRESH MATERIALIZED VIEW vista_sede_statistiche;
    REFRESH MATERIALIZED VIEW vista_libri_ritardo;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.aggiorna_viste_materializzate() OWNER TO federico;

--
-- Name: available_branches(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.available_branches(p_cf_bibliotecario character varying) RETURNS TABLE(id integer, nome character varying, cf character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT s.id, s.nome, b.cf
    FROM sedi AS s
    LEFT JOIN bibliotecario AS b
    ON s.id = b.sede AND b.cf = p_cf_bibliotecario;
END;
$$;


ALTER FUNCTION public.available_branches(p_cf_bibliotecario character varying) OWNER TO federico;

--
-- Name: azzera_ritardi_lettore(character varying); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.azzera_ritardi_lettore(IN _cf character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Resetta i ritardi del lettore specificato
    UPDATE lettore
    SET ritardi = 0
    WHERE cf = _cf;

    -- Conferma l'operazione
    RAISE NOTICE 'Ritardi azzerati per il lettore %', _cf;
END;
$$;


ALTER PROCEDURE public.azzera_ritardi_lettore(IN _cf character varying) OWNER TO federico;

--
-- Name: check_max_prestiti(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.check_max_prestiti(cf_lett character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    categoria tipo_lettore;
    prestiti_correnti INTEGER;
    max_prestiti INTEGER;
BEGIN
    -- Recupera la categoria del lettore
    SELECT l.categoria INTO categoria
    FROM lettore l
    WHERE l.cf = cf_lett;

    -- Conta i prestiti correnti (non restituiti)
    SELECT COUNT(*) INTO prestiti_correnti
    FROM prestiti p
    WHERE p.cf_lettore = cf_lett AND p.data_riconsegna IS NULL;

    -- Definisce il numero massimo di prestiti in base alla categoria
    IF categoria = 'base' THEN
        max_prestiti := 3;
    ELSIF categoria = 'premium' THEN
        max_prestiti := 5;
    ELSE
        RAISE EXCEPTION 'Categoria non valida';
    END IF;

    -- Verifica se il numero massimo di prestiti è stato raggiunto
    IF prestiti_correnti >= max_prestiti THEN
        RETURN FALSE;
    ELSE
        RETURN TRUE;
    END IF;
END;
$$;


ALTER FUNCTION public.check_max_prestiti(cf_lett character varying) OWNER TO federico;

--
-- Name: collega_autore_libro(integer, character varying); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.collega_autore_libro(IN _id_autore integer, IN _isbn_libro character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Verifica se l'associazione esiste già
    IF EXISTS (SELECT 1 FROM scritto WHERE id_autore = _id_autore AND isbn_libro = _isbn_libro) THEN
        RAISE NOTICE 'Autore % è già collegato al libro con ISBN %', _id_autore, _isbn_libro;
    ELSE
        -- Inserisce l'associazione tra autore e libro
        INSERT INTO scritto (id_autore, isbn_libro) VALUES (_id_autore, _isbn_libro);
        RAISE NOTICE 'Autore % collegato al libro con ISBN %', _id_autore, _isbn_libro;
    END IF;
END;
$$;


ALTER PROCEDURE public.collega_autore_libro(IN _id_autore integer, IN _isbn_libro character varying) OWNER TO federico;

--
-- Name: controlla_ritardo_e_aggiorna(integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.controlla_ritardo_e_aggiorna(IN p_id_prestito integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_cf_lettore VARCHAR(16);
    v_data_fine DATE;
    v_data_riconsegna DATE;
BEGIN
    -- Ottiene le informazioni del prestito
    SELECT p.cf_lettore, p.data_fine, p.data_riconsegna
    INTO v_cf_lettore, v_data_fine, v_data_riconsegna
    FROM prestiti p
    WHERE p.id = p_id_prestito;

    -- Verifica se il libro è stato restituito in ritardo
    IF v_data_riconsegna > v_data_fine THEN
        -- Aggiorna il contatore dei ritardi del lettore
        UPDATE lettore
        SET ritardi = ritardi + 1
        WHERE cf = v_cf_lettore;
    END IF;
END;
$$;


ALTER PROCEDURE public.controlla_ritardo_e_aggiorna(IN p_id_prestito integer) OWNER TO federico;

--
-- Name: delete_author_by_id(integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.delete_author_by_id(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Elimina un autore dalla tabella 'autori' utilizzando il suo ID univoco.
    -- L'ID è un valore intero che identifica in modo univoco ogni autore.
    DELETE FROM autori
    WHERE id = p_id;
END;
$$;


ALTER PROCEDURE public.delete_author_by_id(IN p_id integer) OWNER TO federico;

--
-- Name: delete_book_by_isbn(character varying); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.delete_book_by_isbn(IN _isbn character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Elimina un libro dalla tabella 'libri' usando il valore dell'ISBN come identificatore.
    -- L'ISBN è unico per ogni libro, quindi questa query eliminerà un solo record se esiste.
    DELETE FROM libri
    WHERE isbn = _isbn;
END;
$$;


ALTER PROCEDURE public.delete_book_by_isbn(IN _isbn character varying) OWNER TO federico;

--
-- Name: delete_branch(integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.delete_branch(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Elimina una sede specifica dalla tabella 'sedi'
    DELETE FROM sedi
    WHERE id = p_id;
END;
$$;


ALTER PROCEDURE public.delete_branch(IN p_id integer) OWNER TO federico;

--
-- Name: delete_catalogo_entry(integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.delete_catalogo_entry(IN p_catalogo_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM catalogo WHERE id = p_catalogo_id;
END;
$$;


ALTER PROCEDURE public.delete_catalogo_entry(IN p_catalogo_id integer) OWNER TO federico;

--
-- Name: elimina_scritto(integer, character varying); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.elimina_scritto(IN _id_autore integer, IN _isbn_libro character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Elimina la riga dalla tabella scritto
    DELETE FROM scritto
    WHERE id_autore = _id_autore AND isbn_libro = _isbn_libro;
    RAISE NOTICE 'Riga eliminata per autore ID: %, ISBN: %', _id_autore, _isbn_libro;
END;
$$;


ALTER PROCEDURE public.elimina_scritto(IN _id_autore integer, IN _isbn_libro character varying) OWNER TO federico;

--
-- Name: fetch_author_by_id(integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.fetch_author_by_id(p_id integer) RETURNS TABLE(id integer, nome character varying, cognome character varying, biografia text, data_nascita date, data_morte date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT a.id, a.nome, a.cognome, a.biografia, a.data_nascita, a.data_morte
    FROM autori AS a
    WHERE a.id = p_id;
END;
$$;


ALTER FUNCTION public.fetch_author_by_id(p_id integer) OWNER TO federico;

--
-- Name: fetch_authors(integer, integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.fetch_authors(_limit integer, _offset integer) RETURNS TABLE(id integer, nome character varying, cognome character varying, biografia text, data_nascita date, data_morte date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT a.id, a.nome, a.cognome, a.biografia, a.data_nascita, a.data_morte
    FROM autori AS a
    ORDER BY a.id
    LIMIT _limit OFFSET _offset;
END;
$$;


ALTER FUNCTION public.fetch_authors(_limit integer, _offset integer) OWNER TO federico;

--
-- Name: fetch_book_by_isbn(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.fetch_book_by_isbn(_isbn character varying) RETURNS TABLE(isbn character varying, titolo character varying, trama text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT l.isbn, l.titolo, l.trama
    FROM libri AS l
    WHERE l.isbn = _isbn;
END;
$$;


ALTER FUNCTION public.fetch_book_by_isbn(_isbn character varying) OWNER TO federico;

--
-- Name: fetch_books(integer, integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.fetch_books(_limit integer, _offset integer) RETURNS TABLE(isbn character varying, titolo character varying, trama text)
    LANGUAGE plpgsql
    AS $$
BEGIN    
    RETURN QUERY
    SELECT L.isbn, L.titolo, L.trama
    FROM libri AS L
    ORDER BY L.isbn
    LIMIT _limit OFFSET _offset;
END;
$$;


ALTER FUNCTION public.fetch_books(_limit integer, _offset integer) OWNER TO federico;

--
-- Name: fetch_branch_by_id(integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.fetch_branch_by_id(p_id integer) RETURNS TABLE(id integer, nome character varying, indirizzo character varying, cap character varying, comune_id integer, comune_nome character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT s.id, s.nome, s.indirizzo, s.cap, s.comune, c.nome AS comune_nome
    FROM sedi AS s
    JOIN comuni AS c ON s.comune = c.id
    WHERE s.id = p_id;
END;
$$;


ALTER FUNCTION public.fetch_branch_by_id(p_id integer) OWNER TO federico;

--
-- Name: fetch_branches(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.fetch_branches() RETURNS TABLE(id integer, nome character varying, indirizzo character varying, cap character varying, comune integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT s.id, s.nome, s.indirizzo, s.cap, s.comune
    FROM sedi AS s
    ORDER BY s.id;
END;
$$;


ALTER FUNCTION public.fetch_branches() OWNER TO federico;

--
-- Name: get_active_loans(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_active_loans(_cf_lettore character varying) RETURNS TABLE(isbn character varying, titolo character varying, data_inizio date, data_fine date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT c.isbn, l.titolo, p.data_inizio, p.data_fine
    FROM prestiti p
    JOIN catalogo c ON p.id_catalogo = c.id
    JOIN libri l ON c.isbn = l.isbn
    WHERE p.cf_lettore = _cf_lettore
      AND p.data_riconsegna IS NULL;
END;
$$;


ALTER FUNCTION public.get_active_loans(_cf_lettore character varying) OWNER TO federico;

--
-- Name: get_all_sedi(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_all_sedi() RETURNS TABLE(sede_id integer, sede_nome character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT s.id AS sede_id, s.nome AS sede_nome
    FROM sedi s
    ORDER BY s.nome;
END;
$$;


ALTER FUNCTION public.get_all_sedi() OWNER TO federico;

--
-- Name: get_available_branches_by_isbn(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_available_branches_by_isbn(_isbn character varying) RETURNS TABLE(id integer, nome character varying, indirizzo character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT c.id, s.nome, s.indirizzo
    FROM catalogo c
    JOIN sedi s ON c.sede = s.id
    WHERE c.isbn = _isbn;
END;
$$;


ALTER FUNCTION public.get_available_branches_by_isbn(_isbn character varying) OWNER TO federico;

--
-- Name: get_branch_by_cf(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_branch_by_cf(_cf character varying) RETURNS TABLE(id integer, nome character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN    
    RETURN QUERY
    SELECT s.id, s.nome
    FROM bibliotecario b
    JOIN sedi s ON b.sede = s.id
    WHERE b.cf = _cf;
END;
$$;


ALTER FUNCTION public.get_branch_by_cf(_cf character varying) OWNER TO federico;

--
-- Name: get_catalog_by_id_sede(integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_catalog_by_id_sede(p_sede_id integer) RETURNS TABLE(catalogo_id integer, isbn character varying, titolo character varying, disponibile boolean)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id AS catalogo_id,
        l.isbn, 
        l.titolo, 
        -- Verifica se non ci sono prestiti attivi per quel catalogo (prestiti con data_riconsegna NULL)
        CASE WHEN NOT EXISTS (
            SELECT 1 
            FROM prestiti p 
            WHERE p.id_catalogo = c.id 
            AND p.data_riconsegna IS NULL
        ) THEN true ELSE false END AS disponibile
    FROM catalogo c
    JOIN libri l ON c.isbn = l.isbn
    WHERE c.sede = p_sede_id;
END;
$$;


ALTER FUNCTION public.get_catalog_by_id_sede(p_sede_id integer) OWNER TO federico;

--
-- Name: get_catalogo_non_raggruppato(integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_catalogo_non_raggruppato(p_sede_id integer) RETURNS TABLE(catalogo_id integer, isbn character varying, titolo character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT c.id AS catalogo_id, l.isbn, l.titolo
    FROM catalogo c
    JOIN libri l ON c.isbn = l.isbn
    WHERE c.sede = p_sede_id;
END;
$$;


ALTER FUNCTION public.get_catalogo_non_raggruppato(p_sede_id integer) OWNER TO federico;

--
-- Name: get_lettori_con_ritardi(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_lettori_con_ritardi() RETURNS TABLE(cf character varying, nome character varying, cognome character varying, ritardi integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT u.cf, u.nome, u.cognome, l.ritardi
    FROM lettore l
    JOIN utenti u ON l.cf = u.cf
    WHERE l.ritardi > 0;
END;
$$;


ALTER FUNCTION public.get_lettori_con_ritardi() OWNER TO federico;

--
-- Name: get_prestiti_per_sede(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_prestiti_per_sede(_cf_bibliotecario character varying) RETURNS TABLE(id integer, isbn character varying, titolo character varying, cf_lettore character varying, data_inizio date, data_fine date, data_riconsegna date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT p.id, c.isbn, l.titolo, p.cf_lettore, p.data_inizio, p.data_fine, p.data_riconsegna
    FROM prestiti p
    JOIN catalogo c ON p.id_catalogo = c.id
    JOIN libri l ON c.isbn = l.isbn
    JOIN bibliotecario b ON b.sede = c.sede
    WHERE b.cf = _cf_bibliotecario;
END;
$$;


ALTER FUNCTION public.get_prestiti_per_sede(_cf_bibliotecario character varying) OWNER TO federico;

--
-- Name: get_returned_loans(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_returned_loans(_cf_lettore character varying) RETURNS TABLE(isbn character varying, titolo character varying, data_inizio date, data_fine date, data_riconsegna date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT c.isbn, l.titolo, p.data_inizio, p.data_fine, p.data_riconsegna
    FROM prestiti p
    JOIN catalogo c ON p.id_catalogo = c.id
    JOIN libri l ON c.isbn = l.isbn
    WHERE p.cf_lettore = _cf_lettore
      AND p.data_riconsegna IS NOT NULL;
END;
$$;


ALTER FUNCTION public.get_returned_loans(_cf_lettore character varying) OWNER TO federico;

--
-- Name: get_scritto(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_scritto() RETURNS TABLE(id_autore integer, isbn character varying, titolo character varying, nome character varying, cognome character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT a.id AS id_autore, l.isbn, l.titolo, a.nome, a.cognome
    FROM scritto s
    JOIN autori a ON s.id_autore = a.id
    JOIN libri l ON s.isbn_libro = l.isbn
    ORDER BY l.isbn;
END;
$$;


ALTER FUNCTION public.get_scritto() OWNER TO federico;

--
-- Name: get_sede_by_id(integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.get_sede_by_id(p_sede_id integer) RETURNS TABLE(sede_id integer, sede_nome character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT s.id AS sede_id, s.nome AS sede_nome
    FROM sedi s
    WHERE s.id = p_sede_id;
END;
$$;


ALTER FUNCTION public.get_sede_by_id(p_sede_id integer) OWNER TO federico;

--
-- Name: is_book_available(integer); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.is_book_available(_id_catalogo integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    prestiti_attivi integer;
BEGIN
    SELECT COUNT(*)
    INTO prestiti_attivi
    FROM prestiti p
    WHERE p.id_catalogo = _id_catalogo
      AND p.data_riconsegna IS NULL;

       IF prestiti_attivi > 0 THEN
        RETURN false;
    ELSE
        RETURN true;
    END IF;
END;
$$;


ALTER FUNCTION public.is_book_available(_id_catalogo integer) OWNER TO federico;

--
-- Name: limita_prestiti(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.limita_prestiti() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Verifica il numero massimo di prestiti prima di inserire un nuovo prestito
    IF NOT check_max_prestiti(NEW.cf_utente) THEN
        RAISE EXCEPTION 'Numero massimo di prestiti raggiunto per questo lettore';
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.limita_prestiti() OWNER TO federico;

--
-- Name: link_user_branches(character varying, integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.link_user_branches(IN p_cf_bibliotecario character varying, IN p_sede_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Verifica se il bibliotecario è già assegnato a una sede
    IF EXISTS (SELECT 1 FROM bibliotecario WHERE cf = p_cf_bibliotecario) THEN
        -- Aggiorna la sede del bibliotecario
        UPDATE bibliotecario
        SET sede = p_sede_id
        WHERE cf = p_cf_bibliotecario;
    ELSE
        -- Inserisce un nuovo record per il bibliotecario con la nuova sede
        INSERT INTO bibliotecario (cf, sede)
        VALUES (p_cf_bibliotecario, p_sede_id);
    END IF;
END;
$$;


ALTER PROCEDURE public.link_user_branches(IN p_cf_bibliotecario character varying, IN p_sede_id integer) OWNER TO federico;

--
-- Name: proroga_prestito(integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.proroga_prestito(IN id_prestito integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE prestiti
    SET data_fine = data_fine + INTERVAL '1 month'
    WHERE id = id_prestito AND data_riconsegna IS NULL;
END;
$$;


ALTER PROCEDURE public.proroga_prestito(IN id_prestito integer) OWNER TO federico;

--
-- Name: riconsegna_prestito(integer, date); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.riconsegna_prestito(IN p_id_prestito integer, IN p_data_riconsegna date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE prestiti
    SET data_riconsegna = p_data_riconsegna
    WHERE id = p_id_prestito AND data_riconsegna IS NULL;
END;
$$;


ALTER PROCEDURE public.riconsegna_prestito(IN p_id_prestito integer, IN p_data_riconsegna date) OWNER TO federico;

--
-- Name: search_books_by_title(text); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.search_books_by_title(_title text) RETURNS TABLE(isbn character varying, titolo character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT l.isbn, l.titolo::VARCHAR(255)
    FROM libri l
    WHERE l.titolo ILIKE '%' || _title || '%';
END;
$$;


ALTER FUNCTION public.search_books_by_title(_title text) OWNER TO federico;

--
-- Name: search_comune(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.search_comune(p_query character varying) RETURNS TABLE(id integer, nome character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT c.id, c.nome
    FROM comuni AS c
    WHERE c.nome ILIKE p_query || '%'
    LIMIT 10;
END;
$$;


ALTER FUNCTION public.search_comune(p_query character varying) OWNER TO federico;

--
-- Name: show_catalog_by_cf(character varying); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.show_catalog_by_cf(_cf character varying) RETURNS TABLE(titolo character varying, isbn character varying, num_copie integer, disponibili integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT l.titolo, 
           c.isbn, 
           COUNT(*)::integer as num_copie,  -- Numero di copie totale
           (COUNT(*) - COALESCE(
               (SELECT COUNT(*) 
                FROM prestiti p 
                JOIN catalogo c2 ON p.id_catalogo = c2.id
                WHERE c2.isbn = c.isbn
                AND p.data_riconsegna IS NULL), 0))::integer as disponibili  -- Copie disponibili
    FROM catalogo c
    JOIN sedi s ON c.sede = s.id
    JOIN libri l ON c.isbn = l.isbn
    JOIN bibliotecario b ON s.id = b.sede
    WHERE b.cf = _cf
    GROUP BY c.isbn, l.titolo;
END;
$$;


ALTER FUNCTION public.show_catalog_by_cf(_cf character varying) OWNER TO federico;

--
-- Name: trigger_limita_prestiti(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.trigger_limita_prestiti() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Verifica il numero massimo di prestiti prima di inserire un nuovo prestito
    IF NOT check_max_prestiti(NEW.cf_lettore) THEN
        RAISE NOTICE 'Numero massimo di prestiti raggiunto per questo lettore: %', NEW.cf_lettore;
        RETURN NULL;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_limita_prestiti() OWNER TO federico;

--
-- Name: update_author_by_id(integer, character varying, character varying, text, date, date); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.update_author_by_id(IN p_id integer, IN p_nome character varying, IN p_cognome character varying, IN p_biografia text, IN p_data_nascita date, IN p_data_morte date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Aggiorna i dettagli di un autore esistente nella tabella 'autori' usando il suo ID univoco.
    -- Viene aggiornato il nome, cognome, biografia, data di nascita e, se disponibile, la data di morte.
    UPDATE autori
    SET nome = p_nome,               -- Aggiorna il nome dell'autore.
        cognome = p_cognome,         -- Aggiorna il cognome.
        biografia = p_biografia,     -- Aggiorna la biografia (può essere NULL).
        data_nascita = p_data_nascita, -- Aggiorna la data di nascita.
        data_morte = p_data_morte    -- Aggiorna la data di morte (può essere NULL).
    WHERE id = p_id;                 -- L'autore è identificato dal suo ID.
END;
$$;


ALTER PROCEDURE public.update_author_by_id(IN p_id integer, IN p_nome character varying, IN p_cognome character varying, IN p_biografia text, IN p_data_nascita date, IN p_data_morte date) OWNER TO federico;

--
-- Name: update_book_by_isbn(character varying, character varying, text); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.update_book_by_isbn(IN p_isbn character varying, IN p_titolo character varying, IN p_trama text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Aggiornamento del libro nella tabella 'libri'
    UPDATE libri
    SET titolo = p_titolo,
        trama = p_trama
    WHERE isbn = p_isbn;
END;
$$;


ALTER PROCEDURE public.update_book_by_isbn(IN p_isbn character varying, IN p_titolo character varying, IN p_trama text) OWNER TO federico;

--
-- Name: update_branch(integer, character varying, character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: federico
--

CREATE PROCEDURE public.update_branch(IN p_id integer, IN p_nome character varying, IN p_indirizzo character varying, IN p_cap character varying, IN p_comune integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Esegue l'aggiornamento della sede nella tabella 'sedi'
    UPDATE sedi
    SET nome = p_nome,
        indirizzo = p_indirizzo,
        cap = p_cap,
        comune = p_comune
    WHERE id = p_id;
END;
$$;


ALTER PROCEDURE public.update_branch(IN p_id integer, IN p_nome character varying, IN p_indirizzo character varying, IN p_cap character varying, IN p_comune integer) OWNER TO federico;

--
-- Name: verifica_ritardi(); Type: FUNCTION; Schema: public; Owner: federico
--

CREATE FUNCTION public.verifica_ritardi() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Controlla il numero di ritardi del lettore
    IF (SELECT ritardi FROM lettore WHERE cf = NEW.cf_lettore) > 4 THEN
       RAISE NOTICE 'Il lettore con codice fiscale % ha più di 5 ritardi attivi.', NEW.cf_lettore;
       RETURN NULL;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.verifica_ritardi() OWNER TO federico;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.admin (
    cf character varying(16) NOT NULL
);


ALTER TABLE public.admin OWNER TO federico;

--
-- Name: autori; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.autori (
    id integer NOT NULL,
    nome character varying(50) NOT NULL,
    cognome character varying(50) NOT NULL,
    biografia text,
    data_nascita date NOT NULL,
    data_morte date
);


ALTER TABLE public.autori OWNER TO federico;

--
-- Name: autori_id_seq; Type: SEQUENCE; Schema: public; Owner: federico
--

CREATE SEQUENCE public.autori_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.autori_id_seq OWNER TO federico;

--
-- Name: autori_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: federico
--

ALTER SEQUENCE public.autori_id_seq OWNED BY public.autori.id;


--
-- Name: bibliotecario; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.bibliotecario (
    cf character varying(16) NOT NULL,
    sede integer
);


ALTER TABLE public.bibliotecario OWNER TO federico;

--
-- Name: catalogo; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.catalogo (
    id integer NOT NULL,
    sede integer NOT NULL,
    isbn character varying(13) NOT NULL
);


ALTER TABLE public.catalogo OWNER TO federico;

--
-- Name: catalogo_id_seq; Type: SEQUENCE; Schema: public; Owner: federico
--

CREATE SEQUENCE public.catalogo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.catalogo_id_seq OWNER TO federico;

--
-- Name: catalogo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: federico
--

ALTER SEQUENCE public.catalogo_id_seq OWNED BY public.catalogo.id;


--
-- Name: comuni; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.comuni (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    provincia character varying(2)
);


ALTER TABLE public.comuni OWNER TO federico;

--
-- Name: comuni_id_seq; Type: SEQUENCE; Schema: public; Owner: federico
--

CREATE SEQUENCE public.comuni_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comuni_id_seq OWNER TO federico;

--
-- Name: comuni_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: federico
--

ALTER SEQUENCE public.comuni_id_seq OWNED BY public.comuni.id;


--
-- Name: lettore; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.lettore (
    cf character varying(16) NOT NULL,
    categoria public.tipo_lettore NOT NULL,
    ritardi integer DEFAULT 0
);


ALTER TABLE public.lettore OWNER TO federico;

--
-- Name: libri; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.libri (
    isbn character varying(13) NOT NULL,
    titolo character varying(255) NOT NULL,
    trama text
);


ALTER TABLE public.libri OWNER TO federico;

--
-- Name: prestiti; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.prestiti (
    id integer NOT NULL,
    cf_lettore character varying(16) NOT NULL,
    id_catalogo integer NOT NULL,
    data_inizio date NOT NULL,
    data_fine date NOT NULL,
    data_riconsegna date
);


ALTER TABLE public.prestiti OWNER TO federico;

--
-- Name: prestiti_id_seq; Type: SEQUENCE; Schema: public; Owner: federico
--

CREATE SEQUENCE public.prestiti_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prestiti_id_seq OWNER TO federico;

--
-- Name: prestiti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: federico
--

ALTER SEQUENCE public.prestiti_id_seq OWNED BY public.prestiti.id;


--
-- Name: province; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.province (
    sigla character varying(2) NOT NULL,
    nome character varying(50) NOT NULL
);


ALTER TABLE public.province OWNER TO federico;

--
-- Name: scritto; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.scritto (
    id_autore integer NOT NULL,
    isbn_libro character varying(13) NOT NULL
);


ALTER TABLE public.scritto OWNER TO federico;

--
-- Name: sedi; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.sedi (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    indirizzo character varying(255) NOT NULL,
    cap character varying(5),
    comune integer NOT NULL,
    CONSTRAINT chk_cap CHECK (((cap)::text ~ '^\d{5}$'::text))
);


ALTER TABLE public.sedi OWNER TO federico;

--
-- Name: sedi_id_seq; Type: SEQUENCE; Schema: public; Owner: federico
--

CREATE SEQUENCE public.sedi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sedi_id_seq OWNER TO federico;

--
-- Name: sedi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: federico
--

ALTER SEQUENCE public.sedi_id_seq OWNED BY public.sedi.id;


--
-- Name: utenti; Type: TABLE; Schema: public; Owner: federico
--

CREATE TABLE public.utenti (
    cf character varying(16) NOT NULL,
    cognome character varying(50) NOT NULL,
    nome character varying(50) NOT NULL,
    tipo public.tipo_utenti NOT NULL,
    password character varying(64) NOT NULL,
    CONSTRAINT utenti_cf_check CHECK (((cf)::text ~ '^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$'::text)),
    CONSTRAINT utenti_cognome_check CHECK (((cognome)::text ~* '^.+$'::text)),
    CONSTRAINT utenti_nome_check CHECK (((nome)::text ~* '^.+$'::text))
);


ALTER TABLE public.utenti OWNER TO federico;

--
-- Name: vista_libri_ritardo; Type: MATERIALIZED VIEW; Schema: public; Owner: federico
--

CREATE MATERIALIZED VIEW public.vista_libri_ritardo AS
 WITH libri_ritardo AS (
         SELECT p.id AS id_prestito,
            p.cf_lettore,
            l.isbn,
            l.titolo,
            p.data_inizio,
            p.data_fine,
            c.sede
           FROM ((public.prestiti p
             JOIN public.catalogo c ON ((p.id_catalogo = c.id)))
             JOIN public.libri l ON (((c.isbn)::text = (l.isbn)::text)))
          WHERE ((p.data_riconsegna IS NULL) AND (p.data_fine < CURRENT_DATE))
        )
 SELECT id_prestito,
    isbn,
    titolo,
    data_inizio,
    data_fine,
    cf_lettore,
    sede
   FROM libri_ritardo lr
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.vista_libri_ritardo OWNER TO federico;

--
-- Name: vista_sede_statistiche; Type: MATERIALIZED VIEW; Schema: public; Owner: federico
--

CREATE MATERIALIZED VIEW public.vista_sede_statistiche AS
 WITH catalogo_statistiche AS (
         SELECT catalogo.sede,
            count(catalogo.isbn) AS numero_totale_copie_gestite,
            count(DISTINCT catalogo.isbn) AS numero_totale_isbn_gestiti
           FROM public.catalogo
          GROUP BY catalogo.sede
        ), prestiti_statistiche AS (
         SELECT c_1.sede,
            count(
                CASE
                    WHEN (p_1.data_riconsegna IS NULL) THEN 1
                    ELSE NULL::integer
                END) AS numero_prestiti_in_corso,
            count(
                CASE
                    WHEN (p_1.data_riconsegna IS NOT NULL) THEN 1
                    ELSE NULL::integer
                END) AS numero_prestiti_conclusi,
            count(p_1.id) AS numero_totale_prestiti
           FROM (public.prestiti p_1
             JOIN public.catalogo c_1 ON ((c_1.id = p_1.id_catalogo)))
          GROUP BY c_1.sede
        )
 SELECT c.sede,
    c.numero_totale_copie_gestite,
    c.numero_totale_isbn_gestiti,
    COALESCE(p.numero_prestiti_in_corso, (0)::bigint) AS numero_prestiti_in_corso,
    COALESCE(p.numero_prestiti_conclusi, (0)::bigint) AS numero_prestiti_conclusi,
    COALESCE(p.numero_totale_prestiti, (0)::bigint) AS numero_totale_prestiti
   FROM (catalogo_statistiche c
     LEFT JOIN prestiti_statistiche p ON ((c.sede = p.sede)))
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.vista_sede_statistiche OWNER TO federico;

--
-- Name: autori id; Type: DEFAULT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.autori ALTER COLUMN id SET DEFAULT nextval('public.autori_id_seq'::regclass);


--
-- Name: catalogo id; Type: DEFAULT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.catalogo ALTER COLUMN id SET DEFAULT nextval('public.catalogo_id_seq'::regclass);


--
-- Name: comuni id; Type: DEFAULT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.comuni ALTER COLUMN id SET DEFAULT nextval('public.comuni_id_seq'::regclass);


--
-- Name: prestiti id; Type: DEFAULT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.prestiti ALTER COLUMN id SET DEFAULT nextval('public.prestiti_id_seq'::regclass);


--
-- Name: sedi id; Type: DEFAULT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.sedi ALTER COLUMN id SET DEFAULT nextval('public.sedi_id_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.admin (cf) FROM stdin;
\.
COPY public.admin (cf) FROM '$$PATH$$/5004.dat';

--
-- Data for Name: autori; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.autori (id, nome, cognome, biografia, data_nascita, data_morte) FROM stdin;
\.
COPY public.autori (id, nome, cognome, biografia, data_nascita, data_morte) FROM '$$PATH$$/5007.dat';

--
-- Data for Name: bibliotecario; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.bibliotecario (cf, sede) FROM stdin;
\.
COPY public.bibliotecario (cf, sede) FROM '$$PATH$$/5003.dat';

--
-- Data for Name: catalogo; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.catalogo (id, sede, isbn) FROM stdin;
\.
COPY public.catalogo (id, sede, isbn) FROM '$$PATH$$/5010.dat';

--
-- Data for Name: comuni; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.comuni (id, nome, provincia) FROM stdin;
\.
COPY public.comuni (id, nome, provincia) FROM '$$PATH$$/4999.dat';

--
-- Data for Name: lettore; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.lettore (cf, categoria, ritardi) FROM stdin;
\.
COPY public.lettore (cf, categoria, ritardi) FROM '$$PATH$$/5005.dat';

--
-- Data for Name: libri; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.libri (isbn, titolo, trama) FROM stdin;
\.
COPY public.libri (isbn, titolo, trama) FROM '$$PATH$$/5002.dat';

--
-- Data for Name: prestiti; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.prestiti (id, cf_lettore, id_catalogo, data_inizio, data_fine, data_riconsegna) FROM stdin;
\.
COPY public.prestiti (id, cf_lettore, id_catalogo, data_inizio, data_fine, data_riconsegna) FROM '$$PATH$$/5012.dat';

--
-- Data for Name: province; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.province (sigla, nome) FROM stdin;
\.
COPY public.province (sigla, nome) FROM '$$PATH$$/4997.dat';

--
-- Data for Name: scritto; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.scritto (id_autore, isbn_libro) FROM stdin;
\.
COPY public.scritto (id_autore, isbn_libro) FROM '$$PATH$$/5008.dat';

--
-- Data for Name: sedi; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.sedi (id, nome, indirizzo, cap, comune) FROM stdin;
\.
COPY public.sedi (id, nome, indirizzo, cap, comune) FROM '$$PATH$$/5001.dat';

--
-- Data for Name: utenti; Type: TABLE DATA; Schema: public; Owner: federico
--

COPY public.utenti (cf, cognome, nome, tipo, password) FROM stdin;
\.
COPY public.utenti (cf, cognome, nome, tipo, password) FROM '$$PATH$$/4996.dat';

--
-- Name: autori_id_seq; Type: SEQUENCE SET; Schema: public; Owner: federico
--

SELECT pg_catalog.setval('public.autori_id_seq', 57, true);


--
-- Name: catalogo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: federico
--

SELECT pg_catalog.setval('public.catalogo_id_seq', 53, true);


--
-- Name: comuni_id_seq; Type: SEQUENCE SET; Schema: public; Owner: federico
--

SELECT pg_catalog.setval('public.comuni_id_seq', 7789, true);


--
-- Name: prestiti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: federico
--

SELECT pg_catalog.setval('public.prestiti_id_seq', 79, true);


--
-- Name: sedi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: federico
--

SELECT pg_catalog.setval('public.sedi_id_seq', 14, true);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (cf);


--
-- Name: autori autori_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.autori
    ADD CONSTRAINT autori_pkey PRIMARY KEY (id);


--
-- Name: bibliotecario bibliotecario_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.bibliotecario
    ADD CONSTRAINT bibliotecario_pkey PRIMARY KEY (cf);


--
-- Name: catalogo catalogo_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.catalogo
    ADD CONSTRAINT catalogo_pkey PRIMARY KEY (id);


--
-- Name: comuni comuni_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.comuni
    ADD CONSTRAINT comuni_pkey PRIMARY KEY (id);


--
-- Name: lettore lettore_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.lettore
    ADD CONSTRAINT lettore_pkey PRIMARY KEY (cf);


--
-- Name: libri libri_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.libri
    ADD CONSTRAINT libri_pkey PRIMARY KEY (isbn);


--
-- Name: prestiti prestiti_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.prestiti
    ADD CONSTRAINT prestiti_pkey PRIMARY KEY (id);


--
-- Name: province province_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT province_pkey PRIMARY KEY (sigla);


--
-- Name: scritto scritto_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.scritto
    ADD CONSTRAINT scritto_pkey PRIMARY KEY (id_autore, isbn_libro);


--
-- Name: sedi sedi_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.sedi
    ADD CONSTRAINT sedi_pkey PRIMARY KEY (id);


--
-- Name: prestiti unq_prestito_catalogo; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.prestiti
    ADD CONSTRAINT unq_prestito_catalogo UNIQUE (id_catalogo, data_riconsegna);


--
-- Name: utenti utenti_pkey; Type: CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.utenti
    ADD CONSTRAINT utenti_pkey PRIMARY KEY (cf);


--
-- Name: prestiti limita_prestiti_trigger; Type: TRIGGER; Schema: public; Owner: federico
--

CREATE TRIGGER limita_prestiti_trigger BEFORE INSERT ON public.prestiti FOR EACH ROW EXECUTE FUNCTION public.trigger_limita_prestiti();


--
-- Name: catalogo trigger_aggiorna_viste_catalogo; Type: TRIGGER; Schema: public; Owner: federico
--

CREATE TRIGGER trigger_aggiorna_viste_catalogo AFTER INSERT OR DELETE OR UPDATE ON public.catalogo FOR EACH STATEMENT EXECUTE FUNCTION public.aggiorna_viste_materializzate();


--
-- Name: prestiti trigger_aggiorna_viste_prestiti; Type: TRIGGER; Schema: public; Owner: federico
--

CREATE TRIGGER trigger_aggiorna_viste_prestiti AFTER INSERT OR DELETE OR UPDATE ON public.prestiti FOR EACH STATEMENT EXECUTE FUNCTION public.aggiorna_viste_materializzate();


--
-- Name: prestiti trigger_verifica_ritardi; Type: TRIGGER; Schema: public; Owner: federico
--

CREATE TRIGGER trigger_verifica_ritardi BEFORE INSERT ON public.prestiti FOR EACH ROW EXECUTE FUNCTION public.verifica_ritardi();


--
-- Name: admin admin_cf_fkey; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_cf_fkey FOREIGN KEY (cf) REFERENCES public.utenti(cf);


--
-- Name: bibliotecario bibliotecario_cf_fkey; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.bibliotecario
    ADD CONSTRAINT bibliotecario_cf_fkey FOREIGN KEY (cf) REFERENCES public.utenti(cf);


--
-- Name: bibliotecario bibliotecario_sede_fkey; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.bibliotecario
    ADD CONSTRAINT bibliotecario_sede_fkey FOREIGN KEY (sede) REFERENCES public.sedi(id);


--
-- Name: comuni comuni_provincia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.comuni
    ADD CONSTRAINT comuni_provincia_fkey FOREIGN KEY (provincia) REFERENCES public.province(sigla);


--
-- Name: sedi fk_comune; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.sedi
    ADD CONSTRAINT fk_comune FOREIGN KEY (comune) REFERENCES public.comuni(id);


--
-- Name: scritto fk_id_autore; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.scritto
    ADD CONSTRAINT fk_id_autore FOREIGN KEY (id_autore) REFERENCES public.autori(id) ON UPDATE CASCADE;


--
-- Name: catalogo fk_isbn; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.catalogo
    ADD CONSTRAINT fk_isbn FOREIGN KEY (isbn) REFERENCES public.libri(isbn) ON UPDATE CASCADE;


--
-- Name: scritto fk_isbn_libro; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.scritto
    ADD CONSTRAINT fk_isbn_libro FOREIGN KEY (isbn_libro) REFERENCES public.libri(isbn) ON UPDATE CASCADE;


--
-- Name: catalogo fk_sede; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.catalogo
    ADD CONSTRAINT fk_sede FOREIGN KEY (sede) REFERENCES public.sedi(id) ON UPDATE CASCADE;


--
-- Name: lettore lettore_cf_fkey; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.lettore
    ADD CONSTRAINT lettore_cf_fkey FOREIGN KEY (cf) REFERENCES public.utenti(cf);


--
-- Name: prestiti prestiti_cf_lettore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.prestiti
    ADD CONSTRAINT prestiti_cf_lettore_fkey FOREIGN KEY (cf_lettore) REFERENCES public.lettore(cf) ON UPDATE CASCADE;


--
-- Name: prestiti prestiti_id_catalogo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: federico
--

ALTER TABLE ONLY public.prestiti
    ADD CONSTRAINT prestiti_id_catalogo_fkey FOREIGN KEY (id_catalogo) REFERENCES public.catalogo(id) ON UPDATE CASCADE;


--
-- Name: vista_libri_ritardo; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: federico
--

REFRESH MATERIALIZED VIEW public.vista_libri_ritardo;


--
-- Name: vista_sede_statistiche; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: federico
--

REFRESH MATERIALIZED VIEW public.vista_sede_statistiche;


--
-- PostgreSQL database dump complete
--

